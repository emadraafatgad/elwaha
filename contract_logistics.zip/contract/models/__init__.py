# -*- coding: utf-8 -*-

from . import contract
from . import purchase_plan
from . import res_partner
from . import sale_order
from . import project_plan